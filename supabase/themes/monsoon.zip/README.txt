ShopHub theme package

theme.json  - name, description and design tokens (required)
preview.png - image shown on theme cards (optional)

Upload it in Platform -> Themes -> Add theme -> Upload zip file.
